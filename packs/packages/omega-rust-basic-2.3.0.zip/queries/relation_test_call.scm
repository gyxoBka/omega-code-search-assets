(function_item
  (attribute_item (attribute) @attribute)
  name: (identifier) @source
  body: (block
    (expression_statement
      (call_expression
        function: (identifier) @target) @relation))
  (#match? @attribute "test"))

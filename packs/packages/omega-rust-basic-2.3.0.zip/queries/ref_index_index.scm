(index_expression index: (identifier) @name)

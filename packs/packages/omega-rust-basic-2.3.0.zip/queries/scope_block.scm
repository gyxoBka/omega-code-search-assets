(block) @scope

((function_item
  (attribute_item (attribute) @attribute)
  name: (identifier) @name) @test
 (#match? @attribute "test"))
